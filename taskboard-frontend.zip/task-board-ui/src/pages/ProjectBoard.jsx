import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { useParams } from 'react-router-dom';

export default function ProjectBoard() {
  const { id } = useParams();
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    api.get(`/projects/${id}/tasks`).then(res => setTasks(res.data.data));
  }, [id]);

  return (
    <div>
      <h2>Project Board</h2>
      {tasks.map(t => (
        <div key={t.id}>
          <h4>{t.title}</h4>
          <p>{t.status} | {t.priority}</p>
        </div>
      ))}
    </div>
  );
}
