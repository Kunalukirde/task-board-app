using TaskBoard.Api.Models;
using TaskBoard.Api.DTOs;

namespace TaskBoard.Api.Services
{
    public interface IProjectService
    {
        Task<List<Project>> GetAll();
        Task<Project> Create(CreateProjectDto dto);
    }
}
