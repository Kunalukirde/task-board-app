using Microsoft.AspNetCore.Mvc;
using TaskBoard.Api.Services;
using TaskBoard.Api.DTOs;

namespace TaskBoard.Api.Controllers
{
    [ApiController]
    [Route("api/projects")]
    public class ProjectsController : ControllerBase
    {
        private readonly IProjectService _service;

        public ProjectsController(IProjectService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var data = await _service.GetAll();
            return Ok(data);
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateProjectDto dto)
        {
            var project = await _service.Create(dto);
            return Ok(project);
        }
    }
}
